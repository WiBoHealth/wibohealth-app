# 📥 قائمة الملفات المطلوبة لرفع WiBo Health على Vercel

## 📋 الملفات الرئيسية (في الجذر)

انسخ محتوى كل ملف وأنشئه في مجلد المشروع:

### ✅ ملفات الإعدادات الأساسية:
1. **vercel.json** - إعدادات Vercel (مهم جداً!)
2. **manifest.json** - إعدادات PWA
3. **service-worker.js** - Service Worker
4. **robots.txt** - محركات البحث
5. **sitemap.xml** - خريطة الموقع

### ✅ صفحات HTML:
6. **index.html** - الصفحة الرئيسية
7. **foods.html** - دليل الأطعمة (555 صنف)
8. **calculators.html** - الحاسبات الصحية
9. **recipes.html** - الوصفات الصحية
10. **doctor.html** - استشارة طبيب
11. **articles.html** - المقالات الصحية
12. **food-details.html** - تفاصيل الطعام
13. **about.html** - من نحن
14. **contact.html** - اتصل بنا
15. **privacy.html** - سياسة الخصوصية
16. **terms.html** - الشروط والأحكام
17. **pricing.html** - الأسعار

---

## 📁 المجلدات والملفات الفرعية

### 📁 مجلد **css/**
انشئ مجلد اسمه `css` وضع فيه:
- **css/style.css** - التصميم الرئيسي
- **css/mobile-menu.css** - قائمة الهاتف

### 📁 مجلد **js/**
انشئ مجلد اسمه `js` وضع فيه:
- **js/data.js** - بيانات 555 صنف غذائي (ملف كبير)
- **js/main.js** - الوظائف الرئيسية
- **js/mobile-menu.js** - قائمة الهاتف
- **js/pwa-register.js** - تسجيل PWA

### 📁 مجلد **images/**
انشئ مجلد اسمه `images` وضع فيه:

**الصور الموجودة في المشروع:**
- **images/logo.png**
- **images/icon-512.png**
- **images/apple-touch-icon.png**
- **images/splash-screen.png**

**الصور الموجودة على جهازك (أضفها أنت):**
- ✍️ **images/icon-192.png** (192x192)
- ✍️ **images/icon-maskable-192.png** (192x192)
- ✍️ **images/icon-maskable-512.png** (512x512)

### 📁 مجلد **well-known/**
انشئ مجلد اسمه `well-known` وضع فيه:
- **well-known/assetlinks.json** - ربط التطبيق (مهم!)

---

## 🎯 ترتيب العمل الموصى به:

### المرحلة 1: الملفات الأساسية (الأهم)
```
✅ vercel.json
✅ manifest.json
✅ service-worker.js
✅ index.html
✅ well-known/assetlinks.json
```

### المرحلة 2: ملفات CSS و JavaScript
```
✅ css/style.css
✅ css/mobile-menu.css
✅ js/data.js
✅ js/main.js
✅ js/mobile-menu.js
✅ js/pwa-register.js
```

### المرحلة 3: الصفحات الأخرى
```
✅ foods.html
✅ calculators.html
✅ recipes.html
✅ doctor.html
✅ articles.html
... (باقي الصفحات)
```

### المرحلة 4: الصور
```
✅ images/logo.png
✅ images/icon-512.png
✅ images/icon-192.png (من جهازك)
✅ images/icon-maskable-192.png (من جهازك)
✅ images/icon-maskable-512.png (من جهازك)
... (باقي الصور)
```

---

## ⚡ الطريقة السريعة:

بدلاً من نسخ كل ملف يدوياً، يمكنك:

1. **فتح كل ملف في هذا المحادثة**
2. **نسخ المحتوى بالكامل (Ctrl+A, Ctrl+C)**
3. **إنشاء ملف جديد في مجلد المشروع**
4. **لصق المحتوى (Ctrl+V)**
5. **حفظ الملف بنفس الاسم**

---

## 🆘 الملفات الكبيرة:

الملفات التالية **كبيرة الحجم**:
- **js/data.js** (حوالي 190 KB) - بيانات 555 صنف

لهذا الملف، قد تحتاج نسخه على مراحل أو استخدام محرر نصوص قوي مثل:
- Notepad++
- VS Code
- Sublime Text

---

## ✅ Checklist - قائمة تحقق:

- [ ] تم تحميل GitHub Desktop
- [ ] تم تسجيل الدخول بحساب GitHub
- [ ] تم إنشاء مستودع `wibohealth-app`
- [ ] تم نسخ vercel.json
- [ ] تم نسخ manifest.json
- [ ] تم نسخ service-worker.js
- [ ] تم نسخ index.html
- [ ] تم إنشاء مجلد css/
- [ ] تم نسخ ملفات CSS
- [ ] تم إنشاء مجلد js/
- [ ] تم نسخ ملفات JavaScript
- [ ] تم إنشاء مجلد images/
- [ ] تم نسخ الصور
- [ ] تم إضافة الأيقونات الثلاثة من جهازك
- [ ] تم إنشاء مجلد well-known/
- [ ] تم نسخ assetlinks.json
- [ ] تم نسخ باقي صفحات HTML

---

## 🚀 بعد إضافة جميع الملفات:

في **GitHub Desktop**:
1. سترى قائمة بجميع الملفات المضافة
2. اكتب رسالة Commit: "Initial commit - WiBo Health"
3. اضغط **Commit to main**
4. اضغط **Publish repository**
5. اختر **Public** (عام) أو **Private** (خاص)
6. اضغط **Publish**

تم! الملفات الآن على GitHub! ✅

---

## 🔗 الخطوة التالية: ربط Vercel

1. افتح: https://vercel.com
2. سجل دخول
3. اضغط **New Project**
4. اختر **Import Git Repository**
5. اختر **wibohealth-app**
6. اضغط **Deploy**
7. انتظر 1-2 دقيقة
8. ✅ الموقع جاهز!

---

**بالتوفيق! 🎉**
