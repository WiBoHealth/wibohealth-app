# ⚡ البداية السريعة - Trusted Web Activity

## 🎯 الخطوات المختصرة (للمستعجلين!)

### 1️⃣ التحضيرات (مرة واحدة فقط)

```bash
# تحقق من المتطلبات
node --version    # لازم يكون مثبت
java -version     # لازم يكون مثبت

# ثبّت Bubblewrap
npm install -g @bubblewrap/cli
```

---

### 2️⃣ جهّز الأيقونات (قبل البدء)

**محتاج 3 أيقونات إضافية في مجلد `images/`:**

- `icon-192.png` (192x192)
- `icon-maskable-192.png` (192x192)
- `icon-maskable-512.png` (512x512)

**الطريقة السريعة:**
1. اذهب إلى: https://www.pwabuilder.com/imageGenerator
2. ارفع `images/icon-512.png`
3. حمّل ZIP واستخرج الأيقونات
4. ارفعها على Netlify

📖 **دليل مفصل**: `ICONS-GUIDE.md`

---

### 3️⃣ أنشئ التطبيق

```bash
# إنشاء مشروع TWA
bubblewrap init --manifest https://tangerine-smakager-463ba5.netlify.app/manifest.json
```

**أجوبة سريعة للأسئلة:**

```
Domain: tangerine-smakager-463ba5.netlify.app
App ID: com.wibohealth.app
App Name: WiBo Health
Start URL: / (اضغط Enter)
Theme Color: #667eea
Splash Color: #667eea
Display: standalone
Status Bar: #667eea
Notifications: y
Key Alias: wibohealth
Password: [اختر كلمة سر قوية واحفظها!]
```

---

### 4️⃣ ابنِ التطبيق

```bash
cd twa-project
bubblewrap build
```

⏱️ **سيأخذ 2-5 دقائق** (أول مرة فقط)

---

### 5️⃣ الملفات الناتجة

✅ **للنشر على Google Play:**
```
app/build/outputs/bundle/release/app-release.aab
```

✅ **للتجربة على هاتفك:**
```
app/build/outputs/apk/release/app-release-signed.apk
```

---

## 🚀 رفع على Google Play Console

### المتطلبات:
1. حساب Google Play Console ($25 مرة واحدة)
2. سياسة الخصوصية (Privacy Policy) - موجودة في الموقع ✅
3. 2 Screenshots على الأقل من التطبيق
4. وصف التطبيق (موجود جاهز أدناه)

### الخطوات:
1. اذهب إلى: https://play.google.com/console
2. أنشئ تطبيق جديد
3. ارفع ملف: `app-release.aab`
4. املأ المعلومات (استخدم النص الجاهز أدناه)
5. أرسل للمراجعة

---

## 📝 نصوص جاهزة للنشر

### **Short Description (80 حرف):**
```
دليلك الشامل للتغذية الصحية - 555 صنف غذائي وحاسبات صحية احترافية
```

### **Full Description (4000 حرف):**
```
🏥 WiBo Health - دليلك الصحي الشامل

تطبيق صحي شامل يساعدك على اتخاذ قرارات غذائية صحية ذكية!

✨ الميزات الرئيسية:

🍎 دليل الأطعمة (555 صنف):
• معلومات غذائية تفصيلية لكل صنف
• السعرات الحرارية والبروتين والكربوهيدرات والدهون
• الفيتامينات والمعادن الموجودة في كل طعام
• الفوائد الصحية والمحاذير
• بحث وفلترة متقدمة

🧮 الحاسبات الصحية (5 حاسبات):
• حاسبة مؤشر كتلة الجسم (BMI)
• حاسبة معدل الأيض الأساسي (BMR)
• حاسبة السعرات اليومية المطلوبة (TDEE)
• حاسبة احتياج الماء اليومي
• حاسبة احتياج البروتين حسب النشاط

📖 محتوى تعليمي غني:
• 20 وصفة صحية لذيذة مع المقادير والخطوات
• 5 مقالات تغذوية شاملة (الصيام المتقطع، الأطعمة الخارقة، إلخ)
• نصائح طبية وصحية يومية

🎯 ميزات إضافية:
• يعمل بدون إنترنت
• واجهة عربية كاملة وسهلة الاستخدام
• تصميم عصري ومريح للعين
• سرعة فائقة في التصفح
• مناسب لجميع الأعمار

مناسب لـ:
✓ من يريد إنقاص الوزن
✓ الرياضيين ولاعبي كمال الأجسام
✓ مرضى السكري والضغط
✓ الحوامل والمرضعات
✓ الأطفال والمراهقين
✓ كبار السن

التطبيق مجاني بالكامل ولا يحتوي على إعلانات مزعجة!

حمّل الآن وابدأ رحلتك نحو حياة صحية أفضل! 🚀
```

### **App Category:**
```
الصحة واللياقة (Health & Fitness)
```

### **Content Rating:**
```
الجميع (Everyone)
```

---

## 🔑 الحصول على SHA-256 Fingerprint

بعد بناء التطبيق، احصل على fingerprint:

```bash
cd twa-project
keytool -list -v -keystore android.keystore -alias wibohealth
```

**أدخل كلمة السر التي اخترتها**

انسخ **SHA256** واستبدله في ملف:
```
.well-known/assetlinks.json
```

ثم ارفع المشروع على Netlify.

---

## 🆘 المشاكل الشائعة

### خطأ: "bubblewrap: command not found"
```bash
# تأكد من npm global bin في PATH
npm config get prefix
# أضف للـ PATH: /path/to/npm/bin
```

### خطأ: "SDK location not found"
```bash
# Bubblewrap سيحمل Android SDK تلقائياً
# انتظر حتى ينتهي التحميل
```

### خطأ: "Java version not supported"
```bash
# ثبّت Java 17 بالضبط
# Windows: https://adoptium.net
# Mac: brew install openjdk@17
# Linux: sudo apt install openjdk-17-jdk
```

---

## ✅ Checklist قبل النشر

- [ ] الأيقونات الأربعة موجودة في `images/`
- [ ] manifest.json محدّث ومرفوع على Netlify
- [ ] assetlinks.json فيه SHA-256 الصحيح
- [ ] ملف AAB تم بناؤه بنجاح
- [ ] جربت APK على هاتفك (يعمل؟)
- [ ] Screenshots جاهزة (2 على الأقل)
- [ ] حساب Google Play Console جاهز ($25)
- [ ] Privacy Policy موجودة (✅ موجودة في الموقع)

---

## 🎯 الهدف النهائي

**ملف واحد جاهز للرفع على Google Play:**
```
twa-project/app/build/outputs/bundle/release/app-release.aab
```

**هذا كل شيء!** 🎉

---

## 📞 محتاج مساعدة؟

راجع الدليل الكامل في: **TWA-SETUP-GUIDE.md**

أو اسأل وأنا معك خطوة بخطوة! 💪
