# 🎨 دليل سريع لإنشاء الأيقونات المطلوبة

## 📋 الأيقونات المطلوبة:

أنت تحتاج **3 أيقونات إضافية** (عندك `icon-512.png` بالفعل ✅):

1. ✅ **icon-512.png** (512x512) - موجود
2. ❌ **icon-192.png** (192x192) - مطلوب
3. ❌ **icon-maskable-192.png** (192x192) - مطلوب
4. ❌ **icon-maskable-512.png** (512x512) - مطلوب

---

## 🚀 الطريقة السريعة (5 دقائق)

### الخطوة 1: إنشاء جميع الأيقونات دفعة واحدة

اذهب إلى: **https://www.pwabuilder.com/imageGenerator**

1. اضغط **"Upload an image"**
2. ارفع أيقونتك الحالية من: `images/icon-512.png`
3. اضغط **"Generate zip"**
4. حمّل ملف ZIP

### الخطوة 2: استخراج الأيقونات المطلوبة

من ملف ZIP الذي حمّلته، استخرج:

```
android/
  ├── icon-192.png          → انسخه لمجلد images/
  └── icon-512.png          → (موجود عندك)

windows11/
  ├── icon-maskable-192.png → انسخه لمجلد images/
  └── icon-maskable-512.png → انسخه لمجلد images/
```

**أو:**

إذا الأسماء مختلفة، فقط سمّيها:
- أي أيقونة 192x192 عادية → `icon-192.png`
- أي أيقونة 512x512 عادية → `icon-512.png`
- أي أيقونة 192x192 maskable → `icon-maskable-192.png`
- أي أيقونة 512x512 maskable → `icon-maskable-512.png`

---

## 🎯 طريقة بديلة: Maskable.app (إذا PWABuilder ما اشتغل)

### إنشاء Maskable Icons:

1. اذهب إلى: **https://maskable.app/editor**
2. اضغط **"Open icon from file"**
3. ارفع `icon-512.png`
4. اضبط الأيقونة داخل الدائرة الآمنة (المنطقة الزرقاء)
5. اضغط **"Export as"** → اختر:
   - **192x192** → احفظ كـ `icon-maskable-192.png`
   - **512x512** → احفظ كـ `icon-maskable-512.png`

### إنشاء icon-192.png:

1. اذهب إلى: **https://www.iloveimg.com/resize-image**
2. ارفع `icon-512.png`
3. اختر **"By pixels"**
4. أدخل: **192 x 192**
5. حمّل النتيجة وسمّها: `icon-192.png`

---

## 📂 التنظيم النهائي

بعد ما تجهز الأيقونات، مجلد `images/` لازم يكون فيه:

```
images/
  ├── icon-192.png              ← جديد
  ├── icon-512.png              ← موجود ✅
  ├── icon-maskable-192.png     ← جديد
  ├── icon-maskable-512.png     ← جديد
  └── apple-touch-icon.png      ← موجود ✅
```

---

## 🔍 كيف تتأكد من صحة الأيقونات؟

### تحقق من الحجم:

**Windows:**
- انقر يمين على الملف → Properties → Details
- تأكد من: Width = 192 أو 512 / Height = 192 أو 512

**Mac:**
- انقر يمين → Get Info
- تأكد من الأبعاد

**Online:**
- ارفع الصورة على: https://www.metadata2go.com
- سيظهر لك الأبعاد

---

## ⚡ نصيحة سريعة

**إذا عندك Photoshop أو GIMP:**

```
1. افتح icon-512.png
2. Image → Image Size → أدخل 192x192
3. احفظ كـ icon-192.png

4. افتح icon-512.png مرة ثانية
5. أضف Canvas padding من كل جانب 10%
6. احفظ بحجمين: 
   - 192x192 → icon-maskable-192.png
   - 512x512 → icon-maskable-512.png
```

---

## ✅ جاهز؟

بعد ما تجهز الأيقونات الأربعة:

1. ضعها في مجلد `images/`
2. ارفع المشروع على Netlify
3. قلي **"الأيقونات جاهزة"** وسنكمل!

🎯 **الهدف**: جميع الأيقونات في مكانها الصحيح على Netlify عشان Bubblewrap يقرأها!
