# 🚀 دليل رفع موقع WiBo Health على Vercel

## لماذا ننتقل من Netlify إلى Vercel؟

- ❌ **المشكلة في Netlify**: تجاوز حد الاستخدام المجاني (Bandwidth limit)
- ✅ **الحل في Vercel**: Bandwidth غير محدود + خدمة مجانية ممتازة

---

## 📋 المتطلبات

1. حساب GitHub (مجاني)
2. حساب Vercel (مجاني - يمكن التسجيل بحساب GitHub)

---

## 🎯 خطوات الرفع على Vercel

### **الطريقة 1: الرفع عبر GitHub (الموصى بها)**

#### **الخطوة 1: إنشاء مستودع GitHub**

1. اذهب إلى: https://github.com/new
2. أنشئ مستودع جديد:
   - **اسم المستودع**: `wibohealth-app`
   - **الوصف**: WiBo Health - دليلك الشامل للتغذية الصحية
   - **النوع**: Public أو Private (حسب الرغبة)
   - ✅ اضغط **Create repository**

#### **الخطوة 2: رفع الملفات إلى GitHub**

**من جهاز الكمبيوتر:**

```bash
# افتح Command Prompt في مجلد المشروع
cd path\to\your\project

# إذا لم يكن Git مثبت، حمّله من: https://git-scm.com/download/win

# ابدأ Git في المجلد
git init

# أضف جميع الملفات
git add .

# احفظ التغييرات
git commit -m "Initial commit - WiBo Health App"

# اربط المستودع
git remote add origin https://github.com/YOUR_USERNAME/wibohealth-app.git

# ارفع الملفات
git push -u origin main
```

**ملاحظة:** استبدل `YOUR_USERNAME` باسم المستخدم الخاص بك في GitHub.

#### **الخطوة 3: ربط GitHub بـ Vercel**

1. اذهب إلى: https://vercel.com/signup
2. اضغط **Continue with GitHub**
3. سجل دخول بحساب GitHub
4. امنح Vercel الصلاحيات المطلوبة

#### **الخطوة 4: رفع المشروع على Vercel**

1. من لوحة تحكم Vercel، اضغط **Add New** → **Project**
2. اختر المستودع: `wibohealth-app`
3. اضغط **Import**
4. في إعدادات المشروع:
   - **Framework Preset**: Other (أو اتركه تلقائي)
   - **Root Directory**: `./` (الجذر)
   - **Build Command**: اتركه فارغاً (لا نحتاجه)
   - **Output Directory**: اتركه فارغاً
5. اضغط **Deploy**

#### **الخطوة 5: انتظر حتى ينتهي الرفع** ⏰ (1-2 دقيقة)

سترى شاشة تحميل، وعند الانتهاء ستحصل على:
```
🎉 Your project has been deployed!

URL: https://wibohealth-app.vercel.app
```

---

### **الطريقة 2: الرفع المباشر (بدون GitHub)**

#### **باستخدام Vercel CLI:**

```bash
# ثبت Vercel CLI
npm install -g vercel

# افتح Command Prompt في مجلد المشروع
cd path\to\your\project

# سجل دخول
vercel login

# ارفع المشروع
vercel

# للنشر في الإنتاج
vercel --prod
```

---

## ✅ التحقق من نجاح الرفع

بعد انتهاء الرفع، تحقق من:

### **1. الموقع الرئيسي:**
```
https://YOUR-PROJECT-NAME.vercel.app
```

### **2. ملف assetlinks.json:**
```
https://YOUR-PROJECT-NAME.vercel.app/well-known/assetlinks.json
```

يجب أن يظهر المحتوى:
```json
[
  {
    "relation": ["delegate_permission/common.handle_all_urls"],
    "target": {
      "namespace": "android_app",
      "package_name": "com.wibohealth.app",
      "sha256_cert_fingerprints": [
        "84:0A:48:34:40:E9:DB:79:90:CD:3E:AD:A0:09:04:4B:A0:A3:A2:9A:A0:8B:41:F0:CD:E2:CC:AC:30:7F:41:69"
      ]
    }
  }
]
```

### **3. ملف manifest.json:**
```
https://YOUR-PROJECT-NAME.vercel.app/manifest.json
```

---

## 🔄 الخطوة التالية: تحديث التطبيق

بعد نجاح الرفع على Vercel، يجب تحديث رابط الموقع في التطبيق:

### **1. تحديث twa-manifest.json:**

```json
{
  "host": "YOUR-PROJECT-NAME.vercel.app"
}
```

### **2. إعادة بناء التطبيق:**

```bash
cd twa-project-directory
bubblewrap build
```

سيتم إنشاء:
- ✅ ملف APK جديد للتجربة
- ✅ ملف AAB جديد للنشر على Google Play

### **3. تجربة التطبيق:**

قم بتثبيت APK الجديد على هاتفك وتأكد من أنه يعمل بشكل صحيح.

---

## 🎨 تخصيص رابط الموقع (اختياري)

يمكنك ربط دومين خاص بك (مثل: app.wibohealth.com):

1. من لوحة تحكم Vercel
2. اختر المشروع → **Settings** → **Domains**
3. اضغط **Add Domain**
4. أدخل الدومين الخاص بك
5. اتبع التعليمات لإضافة DNS Records

---

## 📊 مقارنة بين Netlify و Vercel

| الميزة | Netlify (المجاني) | Vercel (المجاني) |
|--------|-------------------|-------------------|
| **Bandwidth** | 100 GB/شهر | غير محدود |
| **Build Minutes** | 300 دقيقة/شهر | 6000 دقيقة/شهر |
| **المشاريع** | غير محدود | غير محدود |
| **SSL** | ✅ مجاني | ✅ مجاني |
| **Custom Domain** | ✅ | ✅ |
| **السرعة** | سريع | أسرع |

**الخلاصة:** Vercel أفضل للمشاريع المجانية! 🏆

---

## 🆘 حل المشاكل الشائعة

### **مشكلة 1: ملف assetlinks.json لا يعمل**

**الحل:**
- تأكد من وجود ملف `vercel.json` في جذر المشروع
- تأكد من أن المجلد اسمه `well-known` (بدون نقطة)

### **مشكلة 2: Build Failed**

**الحل:**
- احذف `node_modules` إذا كان موجوداً
- تأكد من ملف `.vercelignore`
- تأكد من أن جميع الملفات HTML/CSS/JS موجودة

### **مشكلة 3: 404 على بعض الصفحات**

**الحل:**
- تأكد من استخدام روابط نسبية (relative paths)
- تحقق من أسماء الملفات (حساسة لحالة الأحرف)

---

## ✨ مميزات إضافية في Vercel

- 🔥 **Preview Deployments**: كل commit يحصل على رابط مؤقت للمعاينة
- 📊 **Analytics**: إحصائيات مجانية للزوار
- 🚀 **Edge Network**: خوادم سريعة حول العالم
- 🔒 **HTTPS تلقائي**: SSL مجاني لجميع المشاريع
- 🎯 **Zero Config**: لا يحتاج إعدادات معقدة

---

## 📞 الدعم

إذا واجهت أي مشكلة:
- 📖 Documentation: https://vercel.com/docs
- 💬 Discord: https://vercel.com/discord
- 🐦 Twitter: @vercel

---

## ✅ Checklist

- [ ] إنشاء حساب GitHub
- [ ] إنشاء مستودع جديد
- [ ] رفع ملفات المشروع
- [ ] إنشاء حساب Vercel
- [ ] ربط GitHub بـ Vercel
- [ ] رفع المشروع
- [ ] التحقق من عمل الموقع
- [ ] التحقق من ملف assetlinks.json
- [ ] تحديث twa-manifest.json
- [ ] إعادة بناء التطبيق
- [ ] تجربة التطبيق على الهاتف
- [ ] رفع AAB إلى Google Play Console

---

**🎉 بالتوفيق! قريباً سيكون تطبيقك على Google Play Store!**
