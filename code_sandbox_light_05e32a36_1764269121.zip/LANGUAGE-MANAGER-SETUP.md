# 🌍 Language Manager Setup Guide
## تفعيل نظام تذكر اللغة التلقائي

### ✅ ما تم إنجازه:

تم إنشاء نظام **Language Manager** ذكي يحفظ تفضيل اللغة في `localStorage` ويقوم تلقائياً بتحويل جميع الصفحات للغة المختارة!

### 📁 الملفات المُنشأة:
- ✅ `js/language-manager.js` - السكريبت الذكي لإدارة اللغة
- ✅ تم إضافة السكريبت لـ:
  - `index.html` ✅
  - `foods.html` ✅

---

## 🚀 **كيف يعمل النظام:**

### المستخدم يختار اللغة مرة واحدة:
1. المستخدم يكبس على زر 🇬🇧 EN (أو 🇸🇦 AR)
2. النظام يحفظ الاختيار في `localStorage`
3. **كل الصفحات الأخرى تتحول تلقائياً** للغة المحفوظة!

### مثال عملي:
```
المستخدم على صفحة /index.html (عربي)
↓
يضغط 🇬🇧 EN
↓
يُحفظ preference: "en" في localStorage
↓
ينتقل لـ /en/index.html (إنجليزي)
↓
يضغط على "Foods"
↓
النظام يفتح /en/foods.html تلقائياً (ليس /foods.html)
↓
كل الموقع صار إنجليزي تلقائياً! 🎉
```

---

## 🔧 **الخطوة التالية:**

### يجب إضافة السكريبت لباقي الصفحات:

#### الطريقة السريعة (افتح كل ملف وأضف قبل `<style>`):

```html
    <!-- Language Manager - Auto Language Switcher -->
    <script src="/js/language-manager.js"></script>

    <style>
```

---

### 📝 **قائمة الصفحات المتبقية:**

#### العربي (Root):
- [ ] supplements.html
- [ ] articles.html
- [ ] recipes.html
- [ ] calculators.html
- [ ] about.html
- [ ] contact.html
- [ ] privacy.html
- [ ] terms.html
- [ ] disclaimer.html
- [ ] doctor.html
- [ ] pricing.html
- [ ] diet-plan.html
- [ ] calorie-tracker.html
- [ ] food-details.html

#### الإنجليزي (en/):
- [ ] en/index.html
- [ ] en/foods.html
- [ ] en/supplements.html
- [ ] en/articles.html
- [ ] en/recipes.html
- [ ] en/calculators.html
- [ ] en/about.html
- [ ] en/contact.html
- [ ] en/privacy.html
- [ ] en/terms.html
- [ ] en/disclaimer.html
- [ ] en/doctor.html
- [ ] en/pricing.html
- [ ] en/diet-plan.html
- [ ] en/calorie-tracker.html
- [ ] en/food-details.html

---

## ✨ **الميزات:**

✅ **تذكر تلقائي**: المستخدم يغير اللغة مرة واحدة، كل الموقع يتحول  
✅ **سلس وسريع**: بدون Reload إضافي  
✅ **localStorage**: يحفظ التفضيل حتى بعد إغلاق المتصفح  
✅ **SEO Friendly**: الروابط تبقى نظيفة (/en/, /)  

---

## 🎯 **التجربة:**

بعد إضافة السكريبت لكل الصفحات:

1. افتح https://wibohealth.com
2. اضغط 🇬🇧 EN
3. تنقل بين الصفحات (Foods, Articles, Recipes...)
4. **كل الصفحات ستكون بالإنجليزي تلقائياً!** 🎉

---

## 🔥 **إنجاز ضخم!**

المستخدم لن يحتاج يدور على زر اللغة في كل صفحة... **مرة واحدة وخلاص!** 🚀

**WiBo Health** صار موقع عالمي بتجربة مستخدم احترافية! 🌍✨
