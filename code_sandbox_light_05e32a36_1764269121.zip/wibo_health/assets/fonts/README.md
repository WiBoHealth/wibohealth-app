# Arabic Fonts for WiBo Health

This folder contains Arabic fonts for the WiBo Health application.

## Fonts Used:
- Cairo-Regular.ttf
- Cairo-Bold.ttf

These fonts are loaded from Google Fonts CDN.
